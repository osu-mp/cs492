package com.example.project3_resume

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
